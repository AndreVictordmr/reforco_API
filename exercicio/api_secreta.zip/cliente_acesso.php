<?php
    $url = "http://localhost/reforco_api/exercicio/api_secreta.php?info=sim";
    $respota = file_get_contents($url);
    
?>
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <body>
        <h1>Tente acessar com a chave certa</h1>
        <hr>
        <p>Obs.:<?php echo $respota;?></p>
        <form action="" method="POST">
            <Label>Você quer sabe a chave para a informaçao?</Label>
            <input type="text" name="chave" >
            <button type="submit">Enviar</button>
        </form>
        <?php 
            if($_SERVER['REQUEST_METHOD']==='POST'){
            $mensagem=trim($_POST['chave']);
            $conect =[
                'http'=>[
                    'header'=>"Content-type: application/json charset= UTF-8\r\n",
                    'method'=>"POST",
                    'content'=>json_encode($mensagem)
                ]
            ];

            $content =stream_context_create($conect);

            $resposta = file_get_contents($url,false, $content);
            echo "<h2>Resposta do chefe</h2>";
            echo "<p>$resposta</p>";
        }
        ?>
    </body>
</html>